#pragma once
#include "../CMD.h"

#define SIZE_BUF	1024 * 1024 * 4 + 100
#define SIZE_HEADER	4

#define DB_SUCCESS		100
#define DB_FAIL			-100
#define FAIL_CMD			-101

#define EXSIST_SEND_BUF		1

#define PATH_SAVE_IMAGE		"E:/DBImage"