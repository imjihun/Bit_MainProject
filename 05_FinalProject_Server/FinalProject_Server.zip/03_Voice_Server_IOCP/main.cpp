#include "01_Main_TCP_Server.h"

int main(int argc, char** argv)
{
	printf("[Voice Server]\n\n");

	Main_TCP_Server(argc, argv);
	return 0;
}